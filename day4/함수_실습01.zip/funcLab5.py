def print_triangle(a):
    if 1<= a <=10:
        for i in range(a,0,-1):
            print('@'*i)
    else:
        pass

print_triangle(2)
print_triangle(20)
print_triangle(5)
print_triangle(3)