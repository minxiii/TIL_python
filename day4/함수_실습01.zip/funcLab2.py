def get_book_title():
    return '파이썬정복'

def get_book_publisher():
    return '한빛미디어'

name = get_book_title()
print(name*2)
print(get_book_publisher())